''' This module is consisted of game logics that are shared by both the console
    version and server version of connectfour.
'''

import connectfour


def show_rules():
    ''' Shows a welcome banner '''
    
    print('''----------------------------------
New game created
The user plays as Red\n
RULES:
Players Red and Yellow take turns.
Valid moves are either "POP" or "DROP", followed by a space and a number from 1 to 7.
Example moves:  DROP 1   drop 1   POP 1   Pop 1\n''')


def make_board(game_state):
    ''' Creates the gameboard. Fills in R for Red player and Y for Yellow player '''
    
    for i in range(len(game_state.board)):
        print(str(i+1), end = '  ')
    print()
     
    for row in range(len(game_state.board[0])):
        for column in range(len(game_state.board)):
            if game_state.board[column][row] == connectfour.RED:      # Replaces '.' with 'R' for Red's move
                state = "R"                                        
            elif game_state.board[column][row] == connectfour.YELLOW: # Replaces '.' with 'Y' for Yellow's move
                state = "Y"
            else:
                state = "."
                
            if column != (connectfour.BOARD_COLUMNS - 1):
                print(state + "  ", end = '')  # Prints out the board's columns with spaces between each spot
            else:
                print(state + '')
                

def decide_turn(game_state):
    ''' Decides on who's turn the game is based on the game_state.turn '''
    
    if game_state.turn == connectfour.RED:      
        turn = "Red"                            # If the turn is 1 (from connectfour.py), turn becomes 'Red'
    elif game_state.turn == connectfour.YELLOW: 
        turn = "Yellow"                         # If the turn is 2, turn becomes 'Yellow'
        
    return turn


def make_action(game_state, turn: str) -> 'game_state' and 'user_input':
    ''' Drops or Pops based on the user input '''
    
    while True:
        try:
            user_input = input('\n' + turn +' player, specify your move: ').strip().upper()
            # Asks for user_input until a valid move is given
            
            if get_action(user_input) == 'DROP':  # Checks whether the move was drop
                move = int(get_column(user_input)) 
                game_state = connectfour.drop(game_state, move-1)
                return (game_state, user_input)

            elif get_action(user_input) == 'POP':  # Checks whether the move was pop
                move = int(get_column(user_input))
                game_state = connectfour.pop(game_state, move-1)
                return (game_state, user_input)

            else:
                raise connectfour_socket.ProtocolError()
            
        except:
            print('Invalid move')


def show_winner(turn: str) -> None:
    ''' Shows the winner of the game '''
    
    print('\nCongratulations! ' + (turn).upper(), 'WON THE GAME!\n\nThe game has ended')


def get_action(string: str) -> str:
    ''' Returns the intended action - either drop or pop from a string '''
    
    return string.split()[0]  # Returns the first string of the two
                              # ex: 'DROP' would be returned if the input string is 'DROP 3'


def get_column(string: str) -> str:
    ''' Returns the intended column number from a string '''
    
    return string.split()[1]  # Returns the second string of the two
