import game_logic
import connectfour_socket


def _ask_host():
    '''
    Asks the user to specify what host they'd like to connect to,
    continuing to ask until a valid answer is given.  A host must not
    be a blank string
    '''
    
    while True:
        host = input('\nHost: ').strip()

        if host == '':
            print('Please specify a host (either a name or an IP address)')
        else:
            return host

    
def _ask_port() -> int:
    '''
    Asks the user to specify what port they'd like to connect to,
    continuing to ask until a valid answer is given.  A port must be an
    integer between 0 and 65535.
    '''

    while True:
        try:
            port = int(input('Port: ').strip())

            if port < 0 or port > 65535:
                print('Ports must be an integer between 0 and 65535')
            else:
                return port

        except ValueError:
            print('Ports must be an integer between 0 and 65535')


def _ask_username():
    ''' Asks for the username until a string without spaces is given '''
    
    while True:

        username = input('\nUsername: ').strip()   # Keeps asking for a username until a valid one is given
        username_list = list(username.split())     # Separates the username by spaces and turns into a list
        if len(username_list) > 1:                 # Checks if there is any space in the username
            print('Username cannot include spaces')
        elif username == '':                       # Username cannot be blank
            print('Username cannot be blank')
            
        else:
            return username


def run_server_user_interface():
    ''' Runs the user interface of the program that plays connectfour against the server '''

    host = _ask_host()
    port = _ask_port()
    
    try:
        connection = connectfour_socket.show_connection(host, port) # Connects to the server
        username = _ask_username()

        response = connectfour_socket.hello(connection, username)   # Logs a user into the connectfour connection
        connectfour_socket.show_welcome(response, username)         # Shows a welcome banner

        response = connectfour_socket.ai_game(connection)           # Sends 'AI_GAME' message to the connectfour server.
        connectfour_socket.show_okay(response)                      # Shows weather the server is ready or not
        
        game_state = game_logic.connectfour.new_game()              
        game_logic.show_rules()                                     # Shows the basic rules

        # The actual game begins here
        connectfour_socket.play_game(connection, game_state)        # The user plays connectfour against the server
             
    except:
        print('Invalid input')

    finally:
        connectfour_socket.close_connection(connection)             # Closes the connection


if __name__ == '__main__':
    
    run_server_user_interface()
