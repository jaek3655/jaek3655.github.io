import url_handling
import class_output


'''
A module that reads the input and constructs the objects that will generate the program's output.
'''



KEY = 'B5DV6HtGP9weNwsfGk6mqI3NUpj8rl4z'

BASE_URL = 'http://open.mapquestapi.com/directions/v2/route'

BASE_ELEVATION_URL =  "http://open.mapquestapi.com/elevation/v1/profile?key=" + KEY + "&inFormat=kvp&shapeFormat=raw&width=425&height=350&latLngCollection="

supported_output = {
                    'STEPS': class_output.Directions(),  # Calls the class Directions()
                    'TOTALTIME': class_output.TotalTime(),
                    'TOTALDISTANCE': class_output.TotalDistance(),
                    'LATLONG': class_output.LatLong(),
                    'ELEVATION': class_output.Elevation(BASE_ELEVATION_URL)
                    }



def _get_locations() -> list:
    ''' Asks for two or more locations '''

    locations = _ask_input()  # Calls this function to reduce repetitive code
    return locations


    
def _get_generators() -> list:
    ''' Asks for one or more outputs/actions to be generated '''
    
    generators = _ask_input()
    return generators



def _ask_input() -> list:
    ''' Asks for user input whether it is locations or generators '''
    
    output_num = int(input("Number of output: "))
    count = 0
    outputs = []
    while count != output_num:
        outputs.append(input("output: "))
        count += 1
    return outputs


def _generate_all_output(json_data: dict, requests: list)-> None:
    ''' Calls all the generator class to generate all of its output method '''
    
    output_generators = []
    for request in requests:
        output_generators.append(supported_output[request])
        
    for generator in output_generators:              
        print()  # A blank line that separates each generated output
        generator.output(json_data)          
    print()
    print("Directions Courtesy of MapQuest; Map Data Copyright OpenStreetMap Contributors")



def _show_result(json_data: dict, requests: list) -> None:
    ''' Shows results if an error did not occur '''
    
    if url_handling.check_error(json_data):
        url_handling.show_error(json_data)  # If an error was found, show error
        
    else:
        _generate_all_output(json_data, requests)                    



def _print_error_and_contributions():
    ''' Prints error messages '''
    
    print('\nMAPQUEST ERROR\n')
    print('Directions Courtesy of MapQuest; Map Data Copyright OpenStreetMap Contributors')



def _run_program():
    ''' Runs the entire program '''
    
    addresses = _get_locations()
    requests = _get_generators()
    url = url_handling.make_url(addresses, KEY, BASE_URL)  # Creates URL

    try:
        json_data = url_handling.get_dict(url)  # Gets dictionary type of json data from the URL
        _show_result(json_data, requests)
        
    except:
        _print_error_and_contributions()  # Shows error





if __name__ == '__main__':
    
    _run_program()


    
