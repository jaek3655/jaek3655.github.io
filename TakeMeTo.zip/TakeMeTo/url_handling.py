import json 
import urllib.parse
import urllib.request


'''
A module that interacts with the Open MapQuest APIs.
Building URLs, making HTTP requests, and parsing JSON responses.
'''


def make_url(addresses: list, KEY: str, BASE_URL: str) -> str:
    ''' Creates an URL based on a given API, base URL and an a list of addresses '''
    
    query_parameters = []
    for address in addresses:
        query_parameters.append(('to', address))
        
    query_parameters[0] = ('from', addresses[0])  # The first location is always the departing point
    key_encoding = urllib.parse.urlencode([('key', KEY)])
    
    return BASE_URL + '?' + key_encoding + '&' + urllib.parse.urlencode(query_parameters)


def make_elevation_url(BASE_ELEVATION_URL: str, lat: float, long: float) -> str:
    ''' Creates an elevation URL based on a given base URL, latidue and longitude'''

    elevation_url = BASE_ELEVATION_URL + str(lat) + ',' + str(long)
    return elevation_url


def get_dict(url: str) -> dict:
    ''' Takes a URL and returns a Python dictionary representing the parsed JSON response '''
    
    response = None
    try:
        # Opens the URL and reads the response.
        # json_text contains the text of the response in JSON format.
        response = urllib.request.urlopen(url)
        json_text = response.read().decode(encoding = 'utf-8')
        
        # Convert json text to a Python object instead.
        return json.loads(json_text)

    finally:
        # Close the response when we're done, assuming that we successfully opened it.
        if response != None:
            response.close()


def check_error(json_data:dict) -> bool:
    ''' Returns True if an error is found '''
    
    if json_data["info"]["statuscode"] == 0:
        return False
    
    error_list = [400,403,500,[600,699]]            # If no route was found, it shows 600 to 603 statuscode

    for status in error_list:                       # Loops through the error_list
        if type(status) == int:                    # Checks whether it is an integer
            if int(json_data["info"]["statuscode"]) == status:   # Returns True to if the webquest API sent an error code
                return True
            
        elif type(status) == list:                 # Checks whether the type of status is a list
            for statusRange in range(status[0],status[1]):                      # Loops through the whole range
                if int(json_data["info"]["statuscode"]) == statusRange:
                    return True


def show_error(json_data: dict) -> None:
    ''' Prints out error messages if no route is found '''
    
    if (json_data['info']['messages'][0] == 'We are unable to route with the given locations.'):
        print('NO ROUTE FOUND')
    else:
        print('MAPQUEST ERROR')
    print("\nDirections Courtesy of MapQuest; Map Data Copyright OpenStreetMap Contributors") 
