import game_logic



def _play_game(game_state):
    ''' The user plays connectfour against another user on the same machine '''
    
    while True:
        if game_logic.connectfour.winner(game_state) != 0:  # Runs if one side wins
            game_logic.make_board(game_state)  # Prints out the board
            game_logic.show_winner(turn)  # Shows the winner banner
            break

        turn = game_logic.decide_turn(game_state)  # Decides who's turn it is                                     
        try:
            game_logic.make_board(game_state)  # Prints out the board
            game_state, user_input = game_logic.make_action(game_state, turn)
            
        except:
            print('\nThe move is invalid! Please try again\n')



def run_console_user_interface():
    ''' Runs the user interface of the program '''
    
    game_logic.show_rules()  # Shows basic rules
    game_state = game_logic.connectfour.new_game()  # Creates a new game
    _play_game(game_state)  # The user plays connectfour
        




if __name__ == '__main__':
    
    run_console_user_interface()






