import socket
import game_logic
import connectfour
from collections import namedtuple



class ProtocolError(Exception):
    pass



_SHOW_DEBUG_TRACE = False  # Set to True to see the conversation between the client and the server



WELCOME = 0
NO_USER = 1
READY = 2
INVALID = 3
WINNER_RED = 4
WINNER_YELLOW = 5
QUIT = 6
                        


ConnectfourConnection = namedtuple(
    'ConnectfourConnection',
    ['socket', 'input', 'output'])



 ##
 ## Below functions are public - used also in other modules
 ##

def show_connection(host: str, port: str) -> 'connection' or 'quit()':
    ''' Shows the status of the connection '''

    print('Connecting to {} (port {})...'.format(host, port))
    connection = _connect(host, port)
    
    if connection == INVALID:
        quit()  # Quits the program if invalid host or port is given

    else:
        print('Connected!')
        return connection



def hello(connection: ConnectfourConnection, username: str):
    '''
    Logs a user into the connectfour connection.
    If the attempt to send text to the server or receive a response
    fails, an exception is raised.
    '''

    _write_line(connection, 'I32CFSP_HELLO ' + username)  # Sends a message to the server
    response = _read_line(connection)                     # with 'I32CFSP ' along with the username.

    if response == 'WELCOME ' + username:
        return WELCOME
    
    elif response.startswith('NO_USER '):
        return NO_USER
    
    else:
        raise ProtocolError()



def ai_game(connection: ConnectfourConnection): # The client requests a game against 
                                                # an artificial intelligence
    '''                                         
    Sends 'AI_GAME' message to the connectfour server.
    If the attempt to send text to the server or receive a response
    fails, an exception is raised.
    '''

    _write_line(connection, 'AI_GAME')
    response = _read_line(connection)
    
    if response == 'READY':  # If the response from the server is 'READY', it is prepared to play a game
        return READY
    
    elif response.startswith('NO_USER '):
        return INVALID
    
    else:
        raise ProtocolError()



def show_welcome(response: str, username: str) -> None:
    ''' Shows a welcome banner with the username'''

    if response == WELCOME:
        print('\nWelcome ' + username)
    
    elif response == NO_USER:
        print('That user does not exist')



def show_okay(response: str) -> None:
    ''' Shows weather the server is ready or not '''
    
    if response == READY:
        pass
    
    elif responese == INVALID:
        print('Invalid')


        
def play_game(connection: ConnectfourConnection, game_state):
    ''' The user plays connectfour against the server '''

    while True:
        turn = game_logic.decide_turn(game_state)
        game_logic.make_board(game_state)
        game_state, user_input = game_logic.make_action(game_state, turn)  # The user makes a move
        game_logic.make_board(game_state)

        turn = game_logic.decide_turn(game_state)
        game_state = _server_turn(connection, game_state, turn, user_input)  # The server makes a move
        
        if game_state == QUIT:  # Breaks if one side wins the game
            break              



def close_connection(connection: ConnectfourConnection):
    print('\nClosing connection...')
    _close(connection)  # Closes the connection
    print('Closed!')



 ##
 ## Below functions are private - used only in this module
 ## 

def _connect(host: str, port: int) -> ConnectfourConnection:
    ''' Connects to the server running on the given host and listening
    on the given port, returning a ConnectfourConnection object describing
    that connection if successful, or raising an exception if the attempt
    to connect fails. '''
    
    try:
        connectfour_socket = socket.socket()
        connectfour_socket.connect((host, port))
        
        connectfour_input = connectfour_socket.makefile('r')
        connectfour_output = connectfour_socket.makefile('w')

        return ConnectfourConnection(
            socket = connectfour_socket,
            input = connectfour_input,
            output = connectfour_output)
    
    except:
        if host != 'woodhouse.ics.uci.edu' and port != 4444:                   # If both host and port are invalid
            print('The connection could not be made because of invalid host and port')
            
        elif host != 'woodhouse.ics.uci.edu':
            print('The connection could not be made because of invalid host')  # If invalid host is given
            
        elif port != 4444:
            print('The connection could not be made because of invalid port')  # If invalid port is given
            
        return INVALID

    

def _server_turn(connection: ConnectfourConnection, game_state, turn: str, user_move: str) -> 'game_state' or QUIT:
    ''' Applies the server's move on the board. Quits if one side wins '''

    _write_line(connection, user_move)
    
    first_line = _read_line(connection)
    if first_line == 'WINNER_RED':     # Checks whether the first line indicates Red's victory
        game_logic.show_winner('RED')  # so that the program does not have to check the second/third line
        return QUIT                    # and if it's Yellow's victory, it would not show up in the first line
    
    second_line = _read_line(connection)
    third_line = _read_line(connection)

    response = first_line + second_line + third_line  # A string that added all the lines sent from the server

    if 'WINNER_RED' in response:       # Server sometimes sends 'WINNER_RED' in second or third line, depending on 
        game_logic.show_winner('RED')  # whether the user's move was pop that caused Red's victory
        return QUIT
    
    elif 'WINNER_YELLOW' in response:  # Runs if the server sends 'WINNER_YELLOW'
        print("\nThe server's (Yellow) move: ", second_line)
        game_state = _server_action(game_state, second_line)
        game_logic.make_board(game_state)
        game_logic.show_winner('YELLOW')
        return QUIT
        
    else:  # Runs if no player has won 
        print("\nThe server's (Yellow) move: ", second_line)
        game_state = _server_action(game_state, second_line)
        return game_state

    

def _server_action(game_state, move: str) -> 'game_state':
    ''' Drops or Pops based on the server input '''

    if game_logic.get_action(move) == 'DROP':        
        move = int(game_logic.get_column(move))
        game_state = connectfour.drop(game_state, move-1)
        return game_state

    elif game_logic.get_action(move) == 'POP':
        move = int(game_logic.get_column(move))
        game_state = connectfour.pop(game_state, move-1)
        return game_state

    

def _close(connection: ConnectfourConnection) -> None:
    ''' Closes the connection to the Connectfour server '''

    connection.input.close()   # Closes the psudo-file object
    connection.output.close()  # Closes the psudo-file object
    connection.socket.close()  # Closes the socket object

    
  
def _read_line(connection: ConnectfourConnection) -> str:
    '''
    Reads a line of text sent from the server and returns it without
    a newline on the end of it
    '''

    # The [:-1] uses the slice notation to remove the last character
    # from the string, which is '\n'
    line = connection.input.readline()[:-1]

    if _SHOW_DEBUG_TRACE:
        print('RCVD: ' + line)

    return line


  
def _write_line(connection: ConnectfourConnection, line: str) -> None:
    '''
    Writes a line of text to the server, including the appropriate
    newline sequence, and ensures that it is sent immediately.
    '''
    connection.output.write(line + '\r\n')
    connection.output.flush()

    if _SHOW_DEBUG_TRACE:
        print('SENT: ' + line)

